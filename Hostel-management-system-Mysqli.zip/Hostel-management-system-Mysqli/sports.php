<center><b>Nov 1'14 (day 1)-<b></center><br>

<center>Football Quarter Final<br>

Table Tennis Quarter Final<br>

Basketball Quarter Final<br>

200m Sprint<br>

Javelin Throw <br>

badminton Quarter Finals<br>

Chess Semi Final<br>

Carrom Final<br></center><br><br>


<center>---------------</center><br>
<center><b>Nov 2'14 (day2)-<b></center><br>

<center>Football Final<br>

Table Tennis Final<br>

Baskeyball Final<br>

400m Sprint<br>

badminton Finals<br>

Chess Final<br>

Cricket finals<br></center>





