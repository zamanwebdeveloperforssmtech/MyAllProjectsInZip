<div align="center">
<h1 style="color:#5B5B5B"><u>ROOM FEES</u></h1>
<table width="1045" height="213" border="1">
  <tbody>
    <tr>
      <td width="241" height="35"><center>SEATERS</center></td>
      <td width="121"><center>First Instalment</center></td>
      <td width="133"><center>Second instalment</center></td>
      <td width="522"><center>Total Fees</center></td>
    </tr>
    <tr>
      <td height="57"><center>Single Seater</center></td>
      <td><center>Rs 32,000/-</center></td>
      <td><center>Rs 32,000/-</center></td>
      <td><center>Rs 64,000/-</center></td>
    </tr>
    <tr>
      <td height="52"><center>Double Seater</center></td>
      <td><center>Rs 20,000/-</center></td>
      <td><center>Rs 40,000/-</center></td>
      <td><center>Rs 60,000/-</center></td>
    </tr>
    <tr>
      <td><center>Triple Seater</center></td>
      <td><center>Rs 28,000/-</center></td>
      <td><center>Rs 28,000/-</center></td>
      <td><center>Rs 56,000/-</center></td>
    </tr>
  </tbody>
</table>
</div>
