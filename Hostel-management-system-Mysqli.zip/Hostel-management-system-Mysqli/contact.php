<h1 style="color:#000000"><b><center>Contact Details</center></b></h1>
<div align="center">
<p><b>Address :</b> ABC Engineering College, XYZ Group, Near AIIMS, New Delhi.
<p><b>Phone :</b> 0000-0000000000<br>
<b>Mobile :</b> +91 9015 501 897
</p>
<p><b>Email :</b> phptpoint@gmail.com</p>
</p>
</div>